package com.example.skillz_minor;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.Skillz.ui.account.AccountsFragment;
import com.example.Skillz.ui.dashboard.DashboardFragment;
import com.example.Skillz.ui.home.HomeFragment;
import com.example.Skillz.ui.search.SearchFragment;
import com.example.skillz_minor.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity{
    /* Button home,search,dash,person;*/
    FragmentManager fragmentManager = getSupportFragmentManager();
    int f=1;
    boolean home = true;
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    HomeFragment homeFragment = new HomeFragment();
    SearchFragment searchFragment = new SearchFragment();
    DashboardFragment dashboardFragment = new DashboardFragment();
    AccountsFragment accountsFragment = new AccountsFragment();
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firebaseAuth = FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser() == null){
            startActivity(new Intent(getApplicationContext(),welcome.class));
            finish();
        }
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_search, R.id.navigation_account)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.navigation_home:
                        if(f!=1){f=f+1;}
                        else{
                            fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, homeFragment).commit();
                            home = true;
                            return true;}
                    case R.id.navigation_search:
                        fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, searchFragment).commit();
                        home = false;
                        return true;
                    case R.id.navigation_dashboard:
                        fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, dashboardFragment).commit();
                        home = false;
                        return true;
                    case R.id.navigation_account:
                        fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, accountsFragment).commit();
                        home = false;
                        return true;
                }
                return false;
            }
        });
        /*fragmentTransaction.add(R.id.nav_host_fragment,courseFragment);
        fragmentTransaction.commit();*/


       /* navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id= item.getItemId();
                switch (id){
                    case R.id.navigation_dashboard:
                       CourseFragment courseFragment = new CourseFragment(5);
                       fragmentTransaction.add(R.id.nav_host_fragment,courseFragment);
                       fragmentTransaction.commit();
                }
                return false;
            }
        });*/
        /*
        if(NavigationUI.onNavDestinationSelected(findViewById(R.id.navigation_home),navController)){
            HomeFragment homeFragment= new HomeFragment();
            fragmentTransaction.add(R.id.nav_host_fragment,homeFragment);
            fragmentTransaction.commit();
        }*/
      /*  home = (Button) findViewById(R.id.homebtn);
        search = (Button) findViewById(R.id.searchbtn);
        dash = (Button) findViewById(R.id.dashbtn);
        person = (Button) findViewById(R.id.personbtn);
        HomeFragment homeFragment = new HomeFragment();
        fragmentTransaction.add(R.id.framelayout, homeFragment);
        fragmentTransaction.commit();
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                HomeFragment homeFragment = new HomeFragment();
                fragmentTransaction.replace(R.id.framelayout, homeFragment);
                fragmentTransaction.commit();
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                SearchFragment searchFragment = new SearchFragment();
                fragmentTransaction.replace(R.id.framelayout, searchFragment);
                fragmentTransaction.commit();
            }
        });
        dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                DashboardFragment dashFragment = new DashboardFragment();
                fragmentTransaction.replace(R.id.framelayout, dashFragment);
                fragmentTransaction.commit();
            }
        });
        person.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                AccountsFragment accountsFragment = new AccountsFragment();
                fragmentTransaction.replace(R.id.framelayout, accountsFragment);
                fragmentTransaction.commit();
            }
        });
    }*/
    }
    @Override
    public void onBackPressed(){
        Fragment fragment= fragmentManager.findFragmentById(R.id.nav_host_fragment);
        fragmentManager.beginTransaction().remove(fragment);
        if(fragment!=null){
            fragmentManager.beginTransaction().remove(fragment).commit();
        }
        else {
            super.onBackPressed();
        }
    }
    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.bottom_nav_menu,menu);
        MenuItem searchItem = menu.findItem(R.id.navigation_search);
        SearchView searchView = (SearchView)searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;
    }*/

}